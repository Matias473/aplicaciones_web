import { Router } from "express";
import { getTime, login, updateTime } from "../controllers/auth.controller";

const router = Router();

// Ruta para login
router.post('/login-user', login);

// Ruta para obtener tiempo restante del token
router.get('/getTime/:userId', getTime);

// Ruta para actualizar el tiempo del token
router.put('/updateTime', updateTime);

export default router;