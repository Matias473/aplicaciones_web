import { Request, Response } from "express";
import { generateAccessToken } from '../utils/generateToken';
import { cache } from '../utils/cache';
import dayjs from "dayjs";

export const login = (req: Request, res: Response) => {
    const { username, password } = req.body;
    
    if (!username || !password) {
        return res.status(400).json({ 
            message: "Username y password son requeridos" 
        });
    }

    if (username !== 'Admin' || password !== '123456789') {
        return res.status(401).json({ 
            message: "Credenciales incorrectas" 
        });
    }

    const userId = 'abc123';
    const accessToken = generateAccessToken(userId);
    
    cache.set(userId, accessToken, 60 * 15);

    return res.json({
        message: 'Login exitoso',
        accessToken,
        userId
    });
};

export const getTime = (req: Request, res: Response) => {
    const { userId } = req.params;
    
    if (!userId) {
        return res.status(400).json({ 
            message: "userId es requerido" 
        });
    }

    const ttl = cache.getTtl(userId);
    
    if (!ttl) {
        return res.status(404).json({ 
            message: "Token no encontrado o expirado" 
        });
    }

    const now = Date.now();
    const timeToLifeSeconds = Math.floor((ttl - now) / 1000);
    const expTime = dayjs(ttl).format('HH:mm:ss');

    return res.json({
        timeToLifeSeconds,
        expTime,
        message: `El token expira en ${timeToLifeSeconds} segundos`
    });
};

export const updateTime = (req: Request, res: Response) => {
    const { userId } = req.body;

    if (!userId) {
        return res.status(400).json({ 
            message: "userId es requerido" 
        });
    }

    const ttl = cache.getTtl(userId);
    if (!ttl) {
        return res.status(404).json({ 
            message: 'Token no encontrado o expirado' 
        });
    }

    const nuevaTTLsegundos = 60 * 15;
    cache.ttl(userId, nuevaTTLsegundos);

    return res.json({ 
        message: "Actualizado con éxito",
        newTTL: nuevaTTLsegundos 
    });
};